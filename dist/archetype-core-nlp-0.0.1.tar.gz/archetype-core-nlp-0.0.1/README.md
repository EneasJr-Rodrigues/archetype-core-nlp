# docker-infra
Configuracao da infra estrutura utiizando docker compose
