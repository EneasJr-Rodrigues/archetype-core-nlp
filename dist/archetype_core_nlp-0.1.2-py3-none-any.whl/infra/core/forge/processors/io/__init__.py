"""Provides Basic IO Operations for Heterogeneous Storage Backends.

"""
from . import (storage,
               stream)
